# EDHR Mobile App

A mobile-first companion app for [EDHR](https://www.edhr.in/), supplied in two formats:

1. **Installable PWA** — a responsive app shell with bottom navigation, quick actions, and install-to-home-screen support.
2. **Android Studio project** — a native Android WebView wrapper that opens the local app shell first, then keeps EDHR pages (sign-in, registration, jobs, resume builder, etc.) inside the app. It supports file selection for website upload controls and delegates phone/email links to the device.

## What's included

- Home screen for school leaders and schools
- Jobs screen linking to EDHR's live vacancy search
- Resume screen linking to EDHR's live resume builder
- Account screen for sign-in and registration
- More screen for About, Services, Plans and Contact
- Responsive layout and bottom navigation
- PWA manifest, app icons, offline app-shell cache and install prompt
- Android launcher icon, WebView, back navigation, file picker and external link handling

## Important backend note

This is a mobile app front end and app wrapper, not a replacement for EDHR's server. Authentication, OTP verification, vacancy data, application submission, document handling, and account dashboards continue to run on EDHR's existing website. The app deliberately links to the official live pages instead of inventing a separate login or job database.

## Preview the PWA locally

From the project root run:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080` in a browser. Service workers and PWA installation require localhost or an HTTPS host.

## Publish the PWA with GitHub Pages

The PWA files (`index.html`, `styles.css`, `app.js`, `manifest.webmanifest`, `service-worker.js`, and `assets/`) are in the project root, so the root folder can be published directly:

1. Create a GitHub repository and upload the root PWA files and `assets/` folder.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select your branch (usually `main`) and the `/(root)` folder, then save.
4. Open the GitHub Pages URL on your phone. On Android Chrome, use **Install app** / **Add to Home screen**. On iPhone Safari, use **Share → Add to Home Screen**.

You may exclude the `android/` folder from a dedicated PWA-only repository, or keep it alongside the website files; GitHub Pages serves the root `index.html`.

## Build the Android app

1. Install Android Studio and an Android SDK (API 35 or newer). Use JDK 17 or the JDK bundled with Android Studio.
2. Open the `android/` folder in Android Studio.
3. Allow Gradle sync to complete. The project uses Android Gradle Plugin `8.7.3` and Kotlin `2.0.21`.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press **Run** to install the app.
6. To create an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The app package ID is `in.edhr.mobile`. Before publishing to Google Play, set the final app signing key, privacy policy URL, support contact, store listing, and target SDK requirements for the release date.

## Project layout

```text
edhr-mobile-app/
├── index.html             # PWA entry point
├── styles.css             # Mobile-first app design
├── app.js                 # Navigation and install support
├── manifest.webmanifest
├── service-worker.js
├── assets/                # PWA icons
└── android/               # Android Studio project
    └── app/src/main/
        ├── AndroidManifest.xml
        ├── java/in/edhr/mobile/MainActivity.kt
        ├── res/
        └── assets/www/    # Same PWA shell bundled inside Android app
```

## Brand and content

The navigation and live destinations are based on pages available on `edhr.in` at the time this project was prepared. The visual identity is an original EDHR-inspired treatment; replace the wordmark or colours with official brand assets if EDHR has a formal brand kit.
